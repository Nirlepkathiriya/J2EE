package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import VO.regvo;
import DAO.regdao;

/**
 * Servlet implementation class regcontroller
 */
@WebServlet("/regcontroller")
public class regcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public regcontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String key=request.getParameter("key");
		if(key.equals("insert"))
		{
			insert(request,response);
			response.sendRedirect("reg.jsp");
		
		}
	}
	
	protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String first=request.getParameter("fn");
		String last=request.getParameter("ln");
		String user=request.getParameter("un");
		String pass=request.getParameter("pw");
		regvo vo=new regvo();
		vo.setFn(first);
		vo.setLn(last);
		vo.setUn(user);
		vo.setPw(pass);
		regdao dao=new regdao();
		dao.insert(vo);
	}

}
