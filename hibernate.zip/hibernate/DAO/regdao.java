package DAO;
import java.sql.*;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import VO.regvo;

public class regdao {
	public void insert(regvo v)
	{
		try
		{
			SessionFactory sf=new Configuration().configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction t=s.beginTransaction();
			s.save(v);
			t.commit();
			s.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
