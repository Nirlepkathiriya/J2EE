package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vo.*;
import dao.*;
import java.util.*;
/*
 * Servlet implementation class reg
 */
@WebServlet("/reg")
public class reg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public reg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String key=request.getParameter("key");
		if(key.equals("search"))
		{
			search(request,response);
			response.sendRedirect("search.jsp");
		}
		else if(key.equals("delete"))
		{
			delete(request,response);
			response.sendRedirect("search.jsp");
		}
	
	}
	
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String firstname=request.getParameter("fn");
		String lastname=request.getParameter("ln");
		String username=request.getParameter("un");
		regdao d=new regdao();
		d.updatenew(firstname,lastname,username);
		search(request,response);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String key=request.getParameter("key");
		if(key.equals("insert"))
		{
			
			insert(request,response);
			response.sendRedirect("reg.jsp");
		}
		else if(key.equals("update"))
		{
			update(request,response);
			response.sendRedirect("search.jsp");
		}
		else if(key.equals("specific"))
		{
			specific(request,response);
			response.sendRedirect("search.jsp");
		}
		
	}
	
	protected void specific(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String username=request.getParameter("username");
		regdao d=new regdao();
		
		List<regvo> ret=d.specificsearch(username);
		System.out.println(ret.size());
		HttpSession session=request.getSession();
		session.setAttribute("list",ret);

		//search(request,response);
		}
	
	
	protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String s1=request.getParameter("fn");
		String s2=request.getParameter("ln");
		String s3=request.getParameter("un");
		String s4=request.getParameter("pw");
		
		regvo v=new regvo();
		v.setFn(s1);
		v.setLn(s2);
		v.setUn(s3);
		v.setPw(s4);
		
		
		regdao d=new regdao();
		d.insert(v);
	
	}
	
	
protected void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		regdao d=new regdao();
		List<regvo> ret=d.sh();
		System.out.println(ret.size());
		HttpSession session=request.getSession();
		session.setAttribute("list",ret);
	}

protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
	String id=request.getParameter("id");
	regdao d=new regdao();
	d.delete(id);
	search(request,response);
	}

}
