package dao;
import vo.*;
import java.util.*;
import java.sql.*;
public class regdao 
{
	public List<regvo> specificsearch(String username)
	{
		List<regvo> ls=new ArrayList<regvo>();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/demodb","root","root");
			Statement s=c.createStatement();
			ResultSet rs=s.executeQuery("select * from new where username='"+username+"'");
			while(rs.next())
			{
				regvo v=new regvo();
				int id=rs.getInt("id");
				String fn=rs.getString("firstname");
				String ln=rs.getString("lastname");
				String un=rs.getString("username");
				String pw=rs.getString("password");
				v.setId(id);
				v.setFn(fn);
				v.setLn(ln);
				v.setUn(un);
				v.setPw(pw);
				ls.add(v);
			}
		}
		catch(Exception e){}
		return ls;
	}
	public void updatenew(String firstname,String lastname,String username)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/demodb","root","root");
			Statement s=c.createStatement();
			s.executeUpdate("update new set firstname='"+firstname+"',lastname='"+lastname+"' where username='"+username+"'");
		}
		catch(Exception e){}
	}
	public void delete(String id)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/demodb","root","root");
			Statement s=c.createStatement();
			s.executeUpdate("delete from new where id='"+id+"'");
		}
		catch(Exception e){}
	}
	public List<regvo> sh()
	{
		List<regvo> ls=new ArrayList<regvo>();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/demodb","root","root");
			Statement s=c.createStatement();
			ResultSet rs=s.executeQuery("select * from new");
			while(rs.next())
			{
				regvo v=new regvo();
				int id=rs.getInt("id");
				String fn=rs.getString("firstname");
				String ln=rs.getString("lastname");
				String un=rs.getString("username");
				String pw=rs.getString("password");
				v.setId(id);
				v.setFn(fn);
				v.setLn(ln);
				v.setUn(un);
				v.setPw(pw);
				ls.add(v);
			}
		}
		catch(Exception e){}
		return ls;
	}
	public void insert(regvo v)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/demodb","root","root");
			Statement s=c.createStatement();
			System.out.println(v.getFn());
			System.out.println(v.getLn());
			System.out.println(v.getUn());
			System.out.println(v.getPw());
			s.executeUpdate("insert into new(firstname,lastname,username,password) values('"+v.getFn()+"','"+v.getLn()+"','"+v.getUn()+"','"+v.getPw()+"')");
			s.close();
			c.close();
		}
		catch(Exception e){}
		
	}
}
